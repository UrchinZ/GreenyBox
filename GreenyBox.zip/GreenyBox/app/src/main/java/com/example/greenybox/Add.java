package com.example.greenybox;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

// back button leads to main page

public class Add extends MainActivity {

    //private field variables in the datepicker class
    private DatePickerDialog mDatePickerDialog;
    private EditText edDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //Showing today's date automatically for purchase date
        String date_n = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
        //get hold of edittext
        EditText date = (EditText) findViewById(R.id.editText2);
        //set it as current date.
        date.setText(date_n);

        /* Tried to calculate Best by date but cannot.. but I'd like to work on this
        EditText best = (EditText) findViewById(R.id.editText3);
        //Calculate Best by based on Expiring in
        best.addTextChangedListener(
                new TextWatcher() {
                    @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
                    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

                    private Timer timer=new Timer();
                    private final long DELAY = 1000; // milliseconds

                    @Override
                    public void afterTextChanged(final Editable s) {
                        timer.cancel();
                        timer = new Timer();
                        timer.schedule(
                                new TimerTask() {
                                    @Override
                                    public void run() {
                                        EditText num = (EditText) findViewById(R.id.editText3);
                                        String getNum = num.getText().toString();
                                        int finalValue=Integer.parseInt(getNum);
                                        String expDate = new java.lang.String ("MM" + "/" + "dd" + finalValue + "/" + "yyyy");
                                        //get hold of edittext
                                        EditText newDate = (EditText) findViewById(R.id.editText4);
                                        //set it as current date.
                                        newDate.setText(expDate);
                                    }
                                },
                                DELAY
                        );
                    }
                }
        );*/

        //Instead of validating date format, I chose to put in datepicker pop up
        edDate = (EditText) findViewById(R.id.editText2);

        setDateTimeField();
        edDate.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mDatePickerDialog.show();
                return false;
            }
        });
    }
    private void setDateTimeField() {

        Calendar newCalendar = Calendar.getInstance();
        mDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                SimpleDateFormat sd = new SimpleDateFormat("MM/dd/yyyy");
                final Date startDate = newDate.getTime();
                String fdate = sd.format(startDate);

                edDate.setText(fdate);

            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        mDatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());

    }

}



//Clicking camera button - open the camera and let user save the picture
//FIGURE OUT LATER

//Automatically calculate expires in day into date - FIGURE OUT LATER

// If the user inputs Best by date, remove Expiring in date - FIGURE OUT LATER

//Clicking button saves into memory
//Creates new grocery item class
